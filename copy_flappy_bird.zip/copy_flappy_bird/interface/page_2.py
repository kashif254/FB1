# By: <Raneem Rana>
# Date: 2024-06-07
# Program Details: <A simple game of Flappy bird.>
import manager,sys
from PySide6.QtGui import QPixmap 
from PySide6.QtWidgets import QMainWindow
from gui.page_2_ui import Ui_MainWindow

class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        with manager.image_gui_path(): self.setupUi(self)
        
    def btn_playagain_a(self):
        manager.widget.setCurrentWidget(manager.screen3)
        manager.widget.resize(664,696)
        self.connect(self.start_game)
        
    def btn_mainmenu_a(self):
        manager.widget.setCurrentWidget(manager.screen1)
        manager.widget.resize(664,696)
        self.connect(self.start_game)
        
    def btn_exit_a(self):
        sys.exit()
    