# By: <Raneem Rana>
# Date: 2024-06-07
# Program Details: <A simple game of Flappy bird.>
import manager,sys
from PySide6.QtGui import QPixmap 
from PySide6.QtWidgets import QMainWindow
from gui.page_1_ui import Ui_MainWindow
from PySide6.QtCore import QTimer

SCREEN_SIZE = 664 * 696
SCREEN_WIDTH = 664
SCREEN_HEIGHT = 696
 
class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        with manager.image_gui_path(): self.setupUi(self)
        self.lbl_bird.setPixmap(QPixmap(u"images/bird1.png"))
        self.lbl_ground = self.lbl_ground.setPixmap(QPixmap(u"images/ground.png"))
        self.lbl_background = self.lbl_background.setPixmap(QPixmap(u"images/background.png"))
        self.timer = QTimer(self)

    #def start_game(self):
    #    self.timer.start(30)
        
    def btn_play_a(self):
        manager.widget.setCurrentWidget(manager.screen3)
        manager.widget.resize(664,696)
    #self.connect(self.start_game)