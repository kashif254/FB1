# By: <Raneem Rana>
# Date: 2024-06-07
# Program Details: <A simple game of Flappy bird.>
import manager,sys
from PySide6.QtGui import QPixmap 
from PySide6.QtWidgets import QMainWindow
from gui.page_3_ui import Ui_MainWindow
from PySide6.QtCore import Qt
from PySide6.QtCore import QRect
from PySide6.QtCore import QTimer
from pygame import mixer
from PySide6.QtWidgets import QLabel
import pygame
import random

SCREEN_SIZE = 664 * 696
SCREEN_WIDTH = 664
SCREEN_HEIGHT = 696

class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        pygame.init()
        mixer.init()
        super().__init__(parent)
        self.setupUi(self)
        self.setGeometry(664,696,664,696)
        #self.timer=QTimer()
        self.timer=QTimer(self)
        self.timer.timeout.connect(self.move_object)
        self.timer.start(10)
        # self.bird_images = [self.lbl_bird.setPixmap(QPixmap(u"images/bird1.png")), self.lbl_bird.setPixmap(QPixmap(u"images/bird2.png")), self.lbl_bird.setPixmap(QPixmap(u"images/bird3.png"))]
        self.bird_images = [QPixmap(u"images/bird1.png"), QPixmap(u"images/bird2.png"), QPixmap(u"images/bird3.png")]
        self.pipe_images = [self.lbl_bird.setPixmap(QPixmap(u"images/pipe.png")), self.lbl_bird.setPixmap(QPixmap(u"images/pipe2.png"))]
        #self.ground_images = [self.lbl_ground.setPixmap(QPixmap(u"images/ground1.png")), self.lbl_ground.setPixmap(QPixmap(u"images/ground2.png")), self.lbl_ground.setPixmap(QPixmap(u"images/ground3.png"))]
        self.ground_images = [QPixmap(u"images/ground.png"), QPixmap(u"images/ground2.png"), QPixmap(u"images/ground3.png")]
        self.bird = (290,240,290,640)
        self.lbl_pipe = self.lbl_pipe.setPixmap(QPixmap(u"images/pipe.png"))
        self.lbl_pipe_2 = self.lbl_pipe_2.setPixmap(QPixmap(u"images/pipe2.png"))
        self.lbl_bird.setPixmap(QPixmap(u"images/bird1.png"))
        self.lbl_roof = self.lbl_roof.setPixmap(QPixmap(u"images/roof.png"))
        self.lbl_ground = self.lbl_ground.setPixmap(QPixmap(u"images/ground.png"))
        self.lbl_background = self.lbl_background.setPixmap(QPixmap(u"images/background.png"))
        self.velocity = 0
        
        self.lbl_bird.setPixmap(self.bird_images[0])
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.animation)
        self.animation_timer.start(100)  # Change image every 100 ms

        self.track_image = 0  

    gameover = True
    speed = 0.5
    gap_between_pipes = 150
    bird_y = 240
    bird_x = 290
    flap = 1
    bird_animation = 0
    background_x = 0
    gravity = 0.5
    falling = False
    groundscroll = 4
    pipescroll = 6
    pipespaces = 200
    move_ground = 0
    #fly = False
    fly = -10
    ground_list = []
    background_scroll = 3
    score = 0
    key_pressed =[]    
    play = False
    time = QTimer
    frames_per_second = 60
    spaces_between_pipes = 90
    pipe_pass = False

    def animation(self):
        self.lbl_bird.setPixmap(self.bird_images[self.track_image])
        self.track_image += 1
        if self.track_image >= len(self.bird_images):
            self.track_image = 0

    def gamestart(self):
        self.timer.start(10)
    
    def move_background(self):
      x = self.speed
      print("in move background block")
      self.lbl_background.move(self.lbl_background.x()-x) 
      self.ground_list = []
      for ground in self.ground_list:
        if self.collision(self.lbl_background,ground):
          self.lbl_background.move(self.lbl_background.x()-x, self.lbl_background.y()-x) 
        self.gameover = True
        
        for image in self.ground_images:
            self.lbl_ground.setPixmap(self.ground_images[0])
    
        self.obstacle_list = []
        for label in self.findChildren(QLabel):
            if label.objectName().startswith("lbl_roof"):
                self.obstacle_list.append(label)
    
    def move_object(self):
      x = self.speed
      y = ((Qt.Key.Key_Space in self.key_pressed) * self.speed)

      self.lbl_pipe.move(self.lbl_pipe.x(),self.lbl_pipe.y()-y) 
      self.lbl_pipe_2.move(self.lbl_pipe_2.x(),self.lbl_pipe_2.y()-y) 

      for ground in self.ground_list:
        if self.collision(self.lbl_bird,ground):
          self.lbl_bird.move(self.lbl_bird.x()-x, self.lbl_bird.y()-y) 
        self.gameover = True
        
        for image in self.pipe_images:
            self.lbl_bird.setPixmap(self.pipe_images[0])

      for wall in self.obstacle_list:
        if self.collision(self.lbl_bird,wall):
          self.lbl_bird.move(self.lbl_bird.x()-x, self.lbl_bird.y()-y)

# if the bird collides with a pipe, roof, or ground label.

    def collision(self, lbl_bird, lbl_pipe):
        lbl_bird_global_top_left = lbl_bird.mapToGlobal(lbl_bird.rect().topLeft())
        ground_global_top_left = lbl_pipe.mapToGlobal(lbl_pipe.rect().topLeft())
        return QRect(lbl_bird_global_top_left, lbl_bird.rect().size()).intersects(QRect(ground_global_top_left, lbl_pipe.rect().size()))

    def collision(self, lbl_bird, lbl_pipe_2):
        lbl_bird_global_top_left = lbl_bird.mapToGlobal(lbl_bird.rect().topLeft())
        ground_global_top_left = lbl_pipe_2.mapToGlobal(lbl_pipe_2.rect().topLeft())
        return QRect(lbl_bird_global_top_left, lbl_bird.rect().size()).intersects(QRect(ground_global_top_left, lbl_pipe_2.rect().size()))

    def collision(self, lbl_bird, lbl_roof):
        lbl_bird_global_top_left = lbl_bird.mapToGlobal(lbl_bird.rect().topLeft())
        ground_global_top_left = lbl_roof.mapToGlobal(lbl_roof.rect().topLeft())
        return QRect(lbl_bird_global_top_left, lbl_bird.rect().size()).intersects(QRect(ground_global_top_left, lbl_roof.rect().size()))

# Making gravity true.

    def keyPressEvent(self, event):
        print("in key press event")
        if event.key() == Qt.Key.Key_Space:
            print("First IF in key press event")
            self.key_pressed.append(event.key)
            self.lbl_bird.move(self.lbl_bird.x(),self.lbl_bird.y()-self.gravity) 
            
    def move_object(self):
      x = self.speed
      y = ((Qt.Key.Key_Space in self.key_pressed) * self.speed)

      self.lbl_bird.move(self.lbl_bird.x(),self.lbl_bird.y()-y) 

# Ground Collision to display gameover

      for ground in self.ground_list:
        if self.collision(self.lbl_bird,ground):
            self.lbl_bird.move(self.lbl_bird.x(), self.lbl_bird.y()-self.gravity) 
        self.gameover = True
        
        for image in self.bird_images:
            self.lbl_bird.setPixmap(self.bird_images[0])
            
        for image in self.ground_images:
            self.lbl_ground.setPixmap(self.ground_images[0])

      self.gravity = ((Qt.Key.Key_Space in self.key_pressed) * self.speed)
      
      # when the space key is released, add gravity (goes down by 0.5)
      # add a timer so it goes down all the time
      
# RELEASE (bird falls each time)

    def keyReleaseEvent(self, event):
        self.timer.start(10)
        
        if event.key() == Qt.Key.Key_Space:
            print("First IF RELEASE KEY Event")
            #self.key_pressed.remove(event.key)
            #self.key_pressed.remove(Qt.Key.Key_Space)
            self.lbl_bird.move(self.lbl_bird.x(), self.lbl_bird.y()+self.gravity)
            if Qt.Key.Key_Space in self.key_pressed:
                print("2nd iF")
                        #self.key_pressed.remove(event.key)  
                self.key_pressed.remove(Qt.Key.Key_Space)
                
                print("did not went to move bird ELSE Part")
        
    def setup_animation(self, value):
        self.animation_timer.stop(1)
        if value:
            self.animation_timer.stop(1)
        else:
            self.animation.setEndValue(0)
            self.animation_timer.start()
            
# def sounds

    def play_sound_effect(self,file_path, volume=1.0):
        sound_effect = mixer.Sound(file_path)
        sound_effect.set_volume(volume)
        sound_effect.play()
        self.play_sound_effect("images/jump.mp3")

    def play_sound_effect(self,file_path, volume=1.0):
        sound_effect = mixer.Sound(file_path)
        sound_effect.set_volume(volume)
        sound_effect.play()
        self.play_sound_effect("images/points.mp3")

    def collision(self, lbl_bird, lbl_ground):
        lbl_bird_global_top_left = lbl_bird.mapToGlobal(lbl_bird.rect().topLeft())
        ground_global_top_left = lbl_ground.mapToGlobal(lbl_ground.rect().topLeft())
        return QRect(lbl_bird_global_top_left, lbl_bird.rect().size()).intersects(QRect(ground_global_top_left, lbl_ground.rect().size()))

# ANIMATION (LOOP)
    def flying_animation(self):
        self.velocity += (self.gravity)
        self.y += self.velocity
        self.lbl_bird.move(self.bird_y)
# Pipe seperation
        self.width = 100
        self.width = self.gap
        while self.gap == 100:
            pass # each pipe need to be apart by 100.
        
# pipe: the height is random, both pipe images are set and follow according to the height. The height is set randomly.
        self.height = random.randint(100, 300)
        self.gap = 100
        self.top_pipe = QPixmap("pipe_top.png") (self.height)
        self.bottom_pipe = QPixmap("pipe_bottom.png")(self.height)

    #    self.x -= self.pipescroll so that the pipes scroll across the screen.

        self.background_x = 0
        self.ground_x = 0
        self.score = 0
        self.timer = QTimer(self)
        self.timer.timeout