# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'page_1.ui'
##
## Created by: Qt User Interface Compiler version 6.5.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QMainWindow, QPushButton,
    QSizePolicy, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(667, 735)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.lbl_ground = QLabel(self.centralwidget)
        self.lbl_ground.setObjectName(u"lbl_ground")
        self.lbl_ground.setGeometry(QRect(0, 560, 671, 191))
        self.lbl_ground.setPixmap(QPixmap(u"../images/ground.png"))
        self.lbl_bird = QLabel(self.centralwidget)
        self.lbl_bird.setObjectName(u"lbl_bird")
        self.lbl_bird.setGeometry(QRect(290, 250, 61, 51))
        self.lbl_bird.setPixmap(QPixmap(u"../images/bird1.png"))
        self.btn_play = QPushButton(self.centralwidget)
        self.btn_play.setObjectName(u"btn_play")
        self.btn_play.setGeometry(QRect(280, 320, 75, 24))
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(130, 180, 391, 51))
        self.label_2.setPixmap(QPixmap(u"../images/text-1718031846793.png"))
        self.label_2.setScaledContents(True)
        self.lbl_background = QLabel(self.centralwidget)
        self.lbl_background.setObjectName(u"lbl_background")
        self.lbl_background.setGeometry(QRect(0, 0, 671, 611))
        self.lbl_background.setPixmap(QPixmap(u"../images/bg.png"))
        self.lbl_background.setScaledContents(True)
        MainWindow.setCentralWidget(self.centralwidget)
        self.lbl_background.raise_()
        self.lbl_ground.raise_()
        self.lbl_bird.raise_()
        self.btn_play.raise_()
        self.label_2.raise_()

        self.retranslateUi(MainWindow)
        self.btn_play.clicked.connect(MainWindow.btn_play_a)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Flappy_Bird", None))
        self.lbl_ground.setText("")
        self.lbl_bird.setText("")
        self.btn_play.setText(QCoreApplication.translate("MainWindow", u"Play", None))
        self.label_2.setText("")
        self.lbl_background.setText("")
    # retranslateUi

