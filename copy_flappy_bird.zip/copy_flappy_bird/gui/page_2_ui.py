# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'page_2.ui'
##
## Created by: Qt User Interface Compiler version 6.5.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QMainWindow, QPushButton,
    QSizePolicy, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(798, 734)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.lbl_background = QLabel(self.centralwidget)
        self.lbl_background.setObjectName(u"lbl_background")
        self.lbl_background.setGeometry(QRect(0, 10, 801, 581))
        font = QFont()
        font.setFamilies([u"Copperplate Gothic Bold"])
        font.setPointSize(12)
        font.setBold(False)
        self.lbl_background.setFont(font)
        self.lbl_background.setPixmap(QPixmap(u"../images/background.png"))
        self.lbl_background.setScaledContents(True)
        self.lbl_ground = QLabel(self.centralwidget)
        self.lbl_ground.setObjectName(u"lbl_ground")
        self.lbl_ground.setGeometry(QRect(0, 560, 811, 191))
        self.lbl_ground.setFont(font)
        self.lbl_ground.setPixmap(QPixmap(u"../images/ground.png"))
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(210, 110, 371, 431))
        self.label.setFont(font)
        self.label.setStyleSheet(u"background-color: rgb(133, 240, 127);border: 6px solid #E9B82B;\n"
"\n"
"border-color: rgb(15, 67, 14);")
        self.btn_playagain = QPushButton(self.centralwidget)
        self.btn_playagain.setObjectName(u"btn_playagain")
        self.btn_playagain.setGeometry(QRect(290, 270, 211, 81))
        self.btn_playagain.setFont(font)
        self.btn_exit = QPushButton(self.centralwidget)
        self.btn_exit.setObjectName(u"btn_exit")
        self.btn_exit.setGeometry(QRect(410, 400, 141, 51))
        self.btn_exit.setFont(font)
        self.btn_mainmenu = QPushButton(self.centralwidget)
        self.btn_mainmenu.setObjectName(u"btn_mainmenu")
        self.btn_mainmenu.setGeometry(QRect(230, 400, 141, 51))
        self.btn_mainmenu.setFont(font)
        self.lbl_score = QLabel(self.centralwidget)
        self.lbl_score.setObjectName(u"lbl_score")
        self.lbl_score.setGeometry(QRect(280, 140, 251, 91))
        self.lbl_score.setFont(font)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        self.btn_playagain.clicked.connect(MainWindow.btn_playagain_a)
        self.btn_mainmenu.clicked.connect(MainWindow.btn_mainmenu_a)
        self.btn_exit.clicked.connect(MainWindow.btn_exit_a)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Flappy_Bird", None))
        self.lbl_background.setText("")
        self.lbl_ground.setText("")
        self.label.setText("")
        self.btn_playagain.setText(QCoreApplication.translate("MainWindow", u"PLAY AGAIN", None))
        self.btn_exit.setText(QCoreApplication.translate("MainWindow", u"Exit", None))
        self.btn_mainmenu.setText(QCoreApplication.translate("MainWindow", u"Main Menu", None))
        self.lbl_score.setText(QCoreApplication.translate("MainWindow", u"Score saved from page 2", None))
    # retranslateUi

