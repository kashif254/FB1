# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'page_3.ui'
##
## Created by: Qt User Interface Compiler version 6.5.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QMainWindow, QSizePolicy,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(664, 735)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.lbl_bird = QLabel(self.centralwidget)
        self.lbl_bird.setObjectName(u"lbl_bird")
        self.lbl_bird.setGeometry(QRect(290, 240, 61, 51))
        self.lbl_bird.setPixmap(QPixmap(u"../images/bird1.png"))
        self.lbl_background = QLabel(self.centralwidget)
        self.lbl_background.setObjectName(u"lbl_background")
        self.lbl_background.setGeometry(QRect(0, -10, 671, 611))
        self.lbl_background.setPixmap(QPixmap(u"../images/bg.png"))
        self.lbl_background.setScaledContents(True)
        self.lbl_ground = QLabel(self.centralwidget)
        self.lbl_ground.setObjectName(u"lbl_ground")
        self.lbl_ground.setGeometry(QRect(0, 560, 671, 191))
        self.lbl_ground.setPixmap(QPixmap(u"../images/ground.png"))
        self.lbl_pipe = QLabel(self.centralwidget)
        self.lbl_pipe.setObjectName(u"lbl_pipe")
        self.lbl_pipe.setGeometry(QRect(530, 300, 61, 271))
        self.lbl_pipe.setPixmap(QPixmap(u"../../flappy_bird/images/pipe.png"))
        self.lbl_pipe.setScaledContents(True)
        self.lbl_pipe_2 = QLabel(self.centralwidget)
        self.lbl_pipe_2.setObjectName(u"lbl_pipe_2")
        self.lbl_pipe_2.setGeometry(QRect(530, -100, 61, 271))
        self.lbl_pipe_2.setPixmap(QPixmap(u"../../flappy_bird/images/pipe2.png"))
        self.lbl_pipe_2.setScaledContents(True)
        self.lbl_roof = QLabel(self.centralwidget)
        self.lbl_roof.setObjectName(u"lbl_roof")
        self.lbl_roof.setGeometry(QRect(0, -130, 671, 151))
        self.lbl_roof.setPixmap(QPixmap(u"../images/roof.png"))
        MainWindow.setCentralWidget(self.centralwidget)
        self.lbl_background.raise_()
        self.lbl_bird.raise_()
        self.lbl_ground.raise_()
        self.lbl_pipe.raise_()
        self.lbl_pipe_2.raise_()
        self.lbl_roof.raise_()

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Flappy_Bird", None))
        self.lbl_bird.setText("")
        self.lbl_background.setText("")
        self.lbl_ground.setText("")
        self.lbl_pipe.setText("")
        self.lbl_pipe_2.setText("")
        self.lbl_roof.setText("")
    # retranslateUi

