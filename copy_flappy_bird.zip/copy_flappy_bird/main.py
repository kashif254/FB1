# By: <Raneem Rana>
# Date: 2024-06-07
# Program Details: <A simple game of Flappy bird.>
import manager
if __name__ == "__main__":
    manager.widget.show()
    manager.screen3.setFocus()
    manager.widget.resize(664,696)
    manager.sys.exit(manager.app.exec())
